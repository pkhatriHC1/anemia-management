# Changelog

All notable changes to `@hc1/design-system` are documented here. This project follows [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.18.4] — 2026-11-13

### Added
- **Base page styles ship with the tokens.** `@hc1com/design-system/styles` now sets the default border colour, the page background, body text colour and font, the pointer cursor on enabled buttons, and a white background when printing. Apps no longer declare these in their own CSS, so `index.css` is just the two imports:
  ```css
  @import "tailwindcss";
  @import "@hc1com/design-system/styles";
  ```

## [0.18.3] — 2026-11-13

### Fixed
- **Sidebar labels were centred** when a `Sidebar.Item` or `Sidebar.Group` used `onClick` instead of a link, because a button centres its text by default. Labels now start at the left in every form.
- **Avatar initials were 11, 13 and 15px** at the sm, md and lg sizes, which are off the type scale. They are now 12, 14 and 16px.

## [0.18.2] — 2026-11-13

### Fixed
- **Surface radius is 12px everywhere.** ChartCard, PatientIdentityStrip and BulkActionBar used the 8px control radius; they now use the 12px surface radius like Card, KpiGroup, Alert, Dialog and Drawer. Controls (buttons, fields, chips) and tiles inside a card keep 8px.
- **KpiCard goal label** sat on the right with an empty space beside it when there was no supporting text. It now starts at the left edge in that case.
- **Card.Actions** are centred against the header text instead of pinned to its top, so a button lines up with a two-line title and description.

## [0.18.1] — 2026-11-13

### Fixed
- **EmptyState, Skeleton and Gauge rendered unstyled in apps.** Their stylesheets are plain CSS imported by the components, but the build only put them in `dist/index.css`, which apps never load. `@hc1com/design-system/styles` now imports them, so an empty state shows its icon circle, centred title and spacing.

## [0.18.0] — 2026-11-13

### Added
- **`FilterChips`** pattern: a row of toggle chips that filter the content below, each with an optional icon and meta line (e.g. count · total), plus a Clear action. Single select; clicking the selected chip clears it.
- **`StepChecklist`** pattern: process steps shown with a completion tick or an empty circle (not form checkboxes), an optional date, click to mark done or undo, and an optional remove action with a confirm. Done steps are not struck through.
- **`DatePicker`** component: a 36px form field (Input styling, 14px label 6px above) that opens the Calendar in a Popover; picking a day closes it. Optional `minDate` / `maxDate`. Use it for every single-date field instead of a native date input.
- Playground pages for FilterChips and StepChecklist; DatePicker shown on the Time Range Filter page.

### Fixed
- **`KpiCard` delta** is rounded to one decimal, so raw ratios ("4.186046…%") never reach the screen.
- **Off-scale text sizes** in ChartCard, CommandPalette, BulkActionBar, FilterBar, SeverityLegend, InlineEdit and PatientIdentityStrip (11/13/15/17px), plus DropdownMenu labels and Combobox, snapped to the type scale (12/14/16/18px).
- **`Tabs` underline:** the tab had rounded top corners, which bent the 2px selected underline up at both ends. Underline tabs are now square; segmented tabs keep their rounded pills.

## [0.17.1] — 2026-11-13

### Fixed
- **Checked checkboxes and radios rendered white.** The indicator's base style set `bg-white` and the checked style set `bg-brand-500`; the variant classes weren't passed through `cn()`, so both classes were applied and white won. The box showed a white tick on white. White now lives only on the unchecked state, and the variant classes go through `cn()`.
- Same `cn()` fix for `Input`, `Select` and `Textarea`, where the base white background could override the disabled grey.

## [0.17.0] — 2026-11-13

### Added
- **`Calendar`** component: single dates or ranges, built on `react-day-picker` (new runtime dependency, installed automatically) and styled only with DS tokens. Keyboard navigation and ARIA grid roles included. No className or style.
- **`TimeRangeFilter`** pattern: preset ranges as segmented pills, plus an optional **Custom** pill that opens a two-month range calendar with Cancel/Apply. The applied range is shown on the pill. Future dates are disabled by default. Goes in `PageHeader`'s `actions` slot, on the title row. Replaces `Tabs variant="segmented"` + native date inputs for dashboard time ranges.
- **`KpiGroup` `title` and `action`**: an optional heading row inside the group's frame. Use it instead of wrapping a KpiGroup in a Card, which drew two borders.

### Docs
- New playground page: Time Range Filter (with the standalone Calendar).

## [0.16.1] — 2026-11-13

### Fixed
- **`KpiCard` content alignment when clickable.** A card with `onClick` renders as a `<button>`, which centres its content vertically, so labels in a `KpiGroup` row sat at different heights. The card is now a top-aligned flex column that fills its grid cell.

### Docs
- README: correct package name (`@hc1com/design-system`); import the styles **in your main CSS file right after `@import "tailwindcss"`** (importing from JS generates no component classes); `react-hook-form` and `recharts` are required whenever you import from `/patterns`; new "release file" install route for Bolt.

## [0.16.0] — 2026-11-11

**The SourceIQ standard: one layout for every hc1 product.**

SourceIQ ("MLP – Source Of Truth") is the visual base for every hc1 product. Every value below was measured in the live SourceIQ prototype and approved in the *SourceIQ Reference Spec — Layout Decisions* sheet. The design system now owns these values, so Bolt prototypes and production code get them by using the components rather than by copying numbers.

### Shell
- **New `AppShell.TopBar`.** A modular top bar, 64px high.
  - Required slots: `product` and `user`.
  - Optional slots, always in this order: `context`, `search`, `assistant` (amber CTA), `notifications` (with count), `help`.
  - There is no `className`, `style` or `children`. Products switch slots on or off; they cannot restyle the bar.
- `AppShell.Main` defaults: 32px padding (`--hc-page-pad`) and a 1440px max width (`--hc-page-max-width`).
- `Sidebar`:
  - the header action is now the amber CTA;
  - nav item radius is 8px (`radius-control`);
  - icons render at 16px (they rendered tiny under the DS spacing scale before).
- `SectionLabel` `md` is now 12px.

### Page
- `PageHeader`: title 24px bold in the new `text-heading` colour (brand-800); subtitle 16px in the new `text-supporting` colour (neutral-600). The built-in bottom margin is removed, because the template owns spacing.
- **`PageTemplate` rewritten.** It owns all vertical spacing: 24px between header and content, and 24px between sections. **The `gap` prop is removed.** New `variant="focused"` gives one centred 896px column, with an optional sticky `footer={{ meta, actions }}` that rests on the bottom edge.
- `Grid` gap defaults to 24px (`--hc-page-grid-gap`). The `gap` prop is deprecated.

### Cards and KPIs
- `Card` padding is 24px (compact: 16px) and the title is 16px semibold. `relaxed` is a deprecated alias of `comfortable`.
- **`KpiCard` rewritten** with three variants, inferred from the data you pass rather than chosen by name:
  - **basic**: label and value;
  - **trend**: adds a `delta` pill and optional `supportingText`;
  - **goal**: adds `goal={{ label, progress, status }}`, drawn with a Progress bar.

  The label is 12px uppercase and the value 24px bold. There is an optional tinted icon tile and a `density="compact"` option. `className` and `style` are removed.
- **New `KpiGroup`.** Joins several KPIs into one card with dividers.
- **New `HeroSummary`.** The single headline banner on a page: 32px value, solid brand-800. Set `ai` to get the teal → amber AI gradient.

### Tables
- Row heights are 36 (compact), 48 (comfortable, one line) and 64 (relaxed, two-line rows).
- Cell padding is 12px.
- Headers are 12px, uppercase, semibold and neutral-500, and stay 48px tall at every density.

### Overlays
- `Dialog`: title 18px semibold, 24px body padding, grey footer band. Sizes stay at 400 / 560 / 720, and the scrim stays at 50% neutral-900 with no blur.
- `Drawer` defaults to `lg` (640px). Every drawer uses this width, the IQ Assistant included. Title 18px.
- **New `AssistantPanel`.** The shared IQ Assistant, built on Drawer: amber AI header with expand and close buttons, message bubbles, composer, footnote and a thinking state.

### Forms and states
- `Input`, `Select` and `Textarea`: labels 14px medium with a 6px gap to the field. Fields are 36px with an 8px radius. Textareas are at least 80px tall.
- **New `FileUpload`.** A dashed drop zone with file-type chips and a hint line.
- `EmptyState`: 48px icon, 16px semibold title, 14px secondary description.
- **`Tabs` gains `variant="segmented"`**, a pill switcher for time ranges and filters with the active pill in brand-800. Use `underline` (the default) for page sections.
- `Progress` `tone="warning"` fill is now amber-500, the CTA amber, instead of dark amber text ink (accent-700). It is lighter and still 3.4:1 against the track, which meets WCAG's 3:1 minimum for UI elements. This also lightens at-risk goal bars on `KpiCard`.
- `Wizard`: step labels are 14px, the current step is brand-800, and upcoming steps are muted.

### Colour
- **AI stays brand amber** (violet was trialled and rejected as off-brand). New `--hc-color-ai-border` (accent-100) for AI content cards. `AiInsightCard`, `HeroSummary ai` (teal → amber gradient) and `AssistantPanel` all read the `--hc-color-ai-*` tokens. See FOUNDATION §8.
- The AI gradient now runs brand-500 → accent-500 → accent-600 (was → accent-400 → accent-300). White text now passes WCAG AA (≥ 4.5:1) everywhere on an AI banner. `HeroSummary` label and supporting text, and the `AssistantPanel` subtitle, are now full white rather than translucent.
- New aliases: `--hc-color-text-heading` and `--hc-color-text-supporting`.

### New tokens
- Shell and page: `--hc-shell-topbar-height`, `--hc-shell-sidebar-width`, `--hc-page-pad`, `--hc-page-max-width`, `--hc-page-focused-width`, `--hc-page-header-gap`, `--hc-page-section-gap`, `--hc-page-grid-gap`, `--hc-page-title-size`, `--hc-page-subtitle-size`, `--hc-page-footer-height`.
- Fields: `--hc-field-height`, `--hc-field-label-gap`, `--hc-textarea-min-height`.

### Added — docs
- New playground pages: `HeroSummary`, `FileUpload` and `AssistantPanel`. `AppShellDoc` gains an `AppShell.TopBar` section, and `KpiCardDoc` is rewritten for the three variants and `KpiGroup`.
- `AssistantPanel` scrolls to the newest message automatically, and respects `prefers-reduced-motion`.

### Fixed
- **`cn()` dropped classes.** Stock tailwind-merge treated DS size classes (`text-14`, `rounded-control`) as conflicting with colour classes and silently removed one of them. `cn()` now uses `extendTailwindMerge` with the DS text and radius scales. This is the same bug fixed for Badge in 0.15, now fixed everywhere.
- **Icons and paddings rendered at a quarter size** in Sidebar, Button, DropdownMenu, Combobox, CommandPalette, PatientIdentityStrip and BulkActionBar. These classes were written for shadcn's 4px spacing scale (`size-4` meaning 16px), but the DS theme reads `size-4` as 4px. They now use explicit `--hc-space-*` values.

### Breaking (pre-1.0)
- `PageTemplate` no longer accepts `gap` or `style`.
- `KpiCard` no longer accepts `className` or `style`. `delta.label` is deprecated in favour of `supportingText`; in development a console warning fires when both are set, because `delta.label` is then ignored.
- `Drawer` default `size` changes from `md` (480px) to `lg` (640px). Drawers that relied on the default get wider; pass `size="md"` to keep the old width for now.
- `AppShell.Main` defaults change: `maxWidth` goes from 100% to 1440px (`--hc-page-max-width`) and `padding` from 24px to 32px (`--hc-page-pad`). On wide screens, content is now centred with a max width instead of stretching edge to edge.
- These changes are visible on screen: table, card and title sizes follow the values above.

## [0.15.0] — 2026-10-30

**Badge: Notion-style density + the font-size that never actually applied.**

Real product feedback flagged the 0.14 badges as too chunky — `md` at `text-14` and `lg` at `text-16` read like page headers, not meta chips. This release shrinks the ladder, adds a new `xs` tier, and fixes a latent `tailwind-merge` bug that was silently dropping font-size on every soft/outline badge for the entire 0.14 line.

### Changed — `Badge` size ladder

| size | text  | padding (y / x) | height |
|------|-------|-----------------|--------|
| xs   | 10px  | 1 / 5           | ~14px  |
| sm   | 12px  | 1 / 6           | ~16px  |
| md   | 12px  | 1 / 8           | ~16px (default — same text/height as sm, roomier horizontal pad) |
| lg   | 14px  | 2 / 9           | ~20px  |

- **Visual change, no API break.** `sm`, `md`, `lg` names are preserved — every existing consumer keeps compiling; badges just render tighter and quieter. The default badge drops from ~20px tall (`text-14` in 0.14) to ~16px tall. Expect downstream UIs to visually reflow where badges were sitting next to the Button baseline or inline in `text-14` body copy.
- **md now matches sm's text size + height.** `md` was always the awkward middle; collapsing it into sm (differentiated purely by horizontal padding) means consumers who stayed on the default don't jump a tier taller than they intended.
- **`lg` is now hero-only.** Reach for `lg` only when the badge *is* the content (header strap, feature callout). Default use → `md`. Dense surfaces → `sm` or `xs`.

### Added — `size="xs"`

New smallest tier (text 10 / ~14px tall) for ultra-dense surfaces: data-table status cells, inline meta on list rows, severity dots with 1-word labels. `BadgeSize` union now includes `'xs'`. Downstream TypeScript consumers see this as a non-breaking type widening.

### Fixed — font-size silently dropped on soft/outline badges (latent since the cva migration)

`Badge.tsx` used the DS `text-12` / `text-14` tokens for the size variant classes. The compound variants that paint color (`text-neutral-700`, `text-brand-500`, etc.) land AFTER the size variant in cva's class concatenation. `tailwind-merge`'s default config can't tell apart a token-named `text-12` (font-size) from `text-neutral-700` (color) — both get bucketed into one `text-*` conflict group and the later one wins. Result: every soft and outline badge inherited the `<html>` default font-size (16px) instead of its intended 12/14 — devtools showed `16px Geist` on labels that `cva` thought it was setting to `12px`.

Fixed by switching the Badge size variants to arbitrary `text-[Npx]` values, which `tailwind-merge` unambiguously classifies as font-size and leaves alone. A comment at the size cva explains the trap so future-us doesn't walk back into it.

Other components that pair DS `text-N` tokens with `text-{color}` in a single `cn()` call (`Drawer`, `Card`, `Radio`, `Tooltip`) likely hit the same latent bug but are not touched in this release — follow-up audit tracked separately.

### Doc updates

`BadgeDoc` Sizes section + prop table + Tokens-used block all reflect the new ladder. The Sizes-section lead explains the deliberate choice to have `sm` and `md` share text size.

## [0.14.0] — 2026-10-08

**Brand typography switch, self-hosted fonts, and the amber CTA.**

The release that moves the DS onto its own typographic identity (Geist, no runtime font dependency on the host app), lands a true amber hero-action variant on `Button`, and re-anchors the AI token family on brand amber instead of borrowed-industry violet. Also fixes a sidebar typography inconsistency flagged during the SourceIQ migration audit, and gates the CI workflows so the mirror and canonical repos stop fighting each other.

### Changed — Typography

- **Source Sans Pro → Geist.** `--hc-font-sans` now resolves to `"Geist", system-ui, …`; `--hc-font-mono` to `"Geist Mono", ui-monospace, …`. Primitive and alias tokens stay named the same, so no consumer rename needed.
- **Self-hosted font faces.** Geist + Geist Mono (weights 400 / 500 / 600 / 700) ship inside the published package at `dist/tokens/css/fonts/*.woff2`. Consumers get them automatically through `import "@hc1com/design-system/styles"` — the Google Fonts `<link>` in `index.html` can be removed. Fontsource is a devDependency only; it is not pulled into consumer `node_modules`.
- **`Sidebar.Item` / `Sidebar.Group` trigger typography** moved to DS body scale (`text-16 leading-normal font-medium`) from the earlier `text-[14px] leading-tight`. Matches `Tabs.tsx` and the `body` type alias; closes a 14-vs-16 inconsistency flagged by the SourceIQ migration audit.

### Added — `Button` variant `"cta"`

A real amber hero-action variant reading from the `--hc-color-cta-*` tokens that already shipped in v0.13.0. The legacy `cta → default` alias row — which incorrectly rendered amber as teal — is removed. `ButtonVariant` promotes `"cta"` from the deprecated-aliases block to canonical. Three documented uses:

1. **Execute / irreversible actions** — Publish, Send, Approve, Pay
2. **Primary entry points** — Upload, Add Files to Analyze
3. **Signature feature launchers** — IQ Assistant, AI tools

Max two CTAs per view. Never on Cancel / Reset / Back.

`ConfirmDialog` gains `variant="cta"` so a non-destructive execute confirm (Publish / Send / Approve) auto-renders its Confirm button in amber without consumers rewiring the button prop.

### Changed — AI token family

The `--hc-color-ai-*` aliases are re-pointed from the violet ramp to the brand amber family. HC1 AI is now on-brand (amber) rather than borrowing the industry-standard violet convention.

- `--hc-color-ai-default` → `--hc-color-accent-500` (was `violet-500`)
- `--hc-color-ai-hover` → `--hc-color-accent-600`
- `--hc-color-ai-subtle-bg` → `--hc-color-accent-50`
- `--hc-color-ai-gradient-from/via/to` → brand-500 / accent-400 / accent-300
- **New** `--hc-color-ai-text` → `--hc-color-accent-700` for AI accents rendered as ink on a white background. Same fill-vs-ink split the DS uses for `severity-high`. Resolves the amber-500 contrast ceiling (~4.5:1 on white — passes AA for large text, borderline for body).

**Violet is retained** as a supporting utility family — chart series (`--hc-color-chart-4`), decorative accents — but is no longer "RESERVED FOR AI MOMENTS ONLY." Products that previously used the violet ramp outside AI contexts can keep those references.

`AiInsightCard` is updated end-to-end: pale amber tint background, amber accent bar, dark amber provenance ink. The copy in `AiInsightCardDoc` is corrected to describe the amber family.

`FOUNDATION.md §8` is rewritten: lists CTA as its own color category alongside Primary / Secondary / Neutral / Status, spells out the AI amber fill-vs-ink pattern, and drops the "AI gradient is violet-to-teal" guidance.

### Changed — CI workflow gating

Both repos (`pkhatriHC1/hc1-design-system` and `hc1com/hc1-design-system`) carry the same workflow files, but each workflow now only runs on the repo that owns its target:

- `deploy-pages.yml` runs only on `pkhatriHC1` (where GitHub Pages is enabled; the canonical docs site at `pkhatrihc1.github.io/hc1-design-system/`).
- `publish.yml` runs only on `hc1com` (where the ambient `GITHUB_TOKEN` has `packages:write` on the `@hc1com` scope).

The wrong-repo runs show as *skipped* instead of failing every push.

### Developer-facing

- `@fontsource/geist` + `@fontsource/geist-mono` added as devDependencies (used only to acquire the woff2 at build time; not in consumer `node_modules`).
- `preview/vite.config.ts` gains `server.fs.allow: [".."]` so the preview dev server can serve woff2 from the parent src tree.

### Migration notes

- **Consumers on Tailwind v3 cannot adopt v0.14.0 directly.** The DS `@theme` block requires Tailwind v4 to generate utility classes. Upgrade Tailwind first.
- **Remove Google Fonts `<link>` tags from `index.html`.** Any `fonts.googleapis.com` reference for Source Sans Pro, Geist, or JetBrains Mono is now redundant and can be deleted.
- **Products using `--hc-color-ai-*` tokens** will see an automatic color shift (violet → amber). No code change required; the token names are stable.
- **Products using violet shades directly** (`var(--hc-color-violet-*)`) are unaffected — the ramp is retained.
- **No breaking Button API changes.** Existing `variant="cta"` call sites that were rendering teal (incorrectly) will now render the intended amber.

---

## [0.13.0] — 2026-09-10

**Chart palette + status-muted aliases (foundation-token gap-fill).**

First DS release driven by the full sourceIQ token audit (see
`sourceiq-hc1com/docs/DS_TOKEN_MIGRATION.md`). The audit inventoried every
local `--var: value;` in sourceIQ's `index.css` and mapped each to the
closest DS primitive using ΔE distance in oklab space. Two gaps needed
new DS aliases before sourceIQ could migrate cleanly:

1. **Chart palette** — sourceIQ had `--chart-1..5` as bare oklch values with no DS counterpart. Every product that uses recharts had to redefine the same rotation.
2. **Status "-muted" aliases** — sourceIQ (and typical shadcn products) name pale status backgrounds `--success-muted` / `--warning-muted`, not `--status-success-bg`. Fine, but the naming mismatch meant every product wrote the same aliases in :root.

Both now ship as DS primitives so products stop redefining them.

### Added — `--hc-color-chart-1..5`

Five-color rotating pool for bar/line/pie/area chart series. Every entry is an alias to an existing DS primitive (no new hex values introduced):

- `--hc-color-chart-1` → `--hc-color-brand-500` (primary teal)
- `--hc-color-chart-2` → `--hc-color-brand-300` (light teal)
- `--hc-color-chart-3` → `--hc-color-accent-400` (amber)
- `--hc-color-chart-4` → `--hc-color-violet-500` (violet)
- `--hc-color-chart-5` → `--hc-color-green-400` (green)

Products point their `--chart-N` at these directly. Individual overrides at the product level still work — a product with a specific series color for "spend" can override `--hc-color-chart-1` in :root without affecting anything else.

### Added — `--hc-color-status-*-muted` aliases

Ergonomic aliases pointing to the existing `-bg` variants:

- `--hc-color-status-success-muted` → `--hc-color-status-success-bg`
- `--hc-color-status-warning-muted` → `--hc-color-status-warning-bg`
- `--hc-color-status-error-muted` → `--hc-color-status-error-bg`
- `--hc-color-status-info-muted` → `--hc-color-status-info-bg`

Same value, exposed under the naming products actually use.

### Verified

- No visual diff in any component — all new tokens are aliases to primitives that were already resolving to the same colors.
- SourceIQ `index.css` rewrite: every `:root` semantic override now points at a DS primitive (5 semantic + 6 status + 5 chart + 5 sidebar chrome vars — 21 total). Six local `oklch()` values remained as-is: the `.dark` block (DS has no dark ramp yet), the `--radius` root (product-owned), and the spacing scale (stock-Tailwind restoration).

---

## [0.12.2] — 2026-09-10

**Brand-tinted hover states for muted button variants.**

Follow-up to 0.12.1 based on visual feedback: the `outline`, `secondary`,
and `ghost` variants used a flat neutral hover (`--hc-color-bg-muted`)
that felt disconnected from HC1 identity. Every product on the DS should
"feel HC1" on every interaction, not just at rest.

### Changed — hover states now brand-tinted

- **`outline`** hover: `--hc-color-bg-muted` → `--hc-color-brand-50` (#DAEEF0), border → `--hc-color-brand-100`
- **`secondary`** hover: `--hc-color-bg-muted` → `--hc-color-brand-50` (#DAEEF0), border → `--hc-color-brand-100`
- **`ghost`** hover: `--hc-color-bg-muted` → `--hc-color-brand-50` (#DAEEF0)
- All three variants now use `--hc-color-brand-100` for `active:` state, giving a consistent press-down feedback tied to the brand ramp.

`default` (brand fill), `destructive` (severity red), and `link` variants are untouched — they already have strong identity states.

### Rationale

`--hc-color-brand-50` is the palest tint on the HC1 brand teal ramp
(hex `#DAEEF0`). It sits between white and the primary teal, so hovering
a neutral button gives a barely-there hint of brand color without
turning the button into a "second primary". Consumers who want to
retune per-product can override `--hc-color-brand-50` / `--hc-color-brand-100`
in `:root`.

### Verified

- Byte-for-byte diff limited to the three variant class strings in `Button.tsx`.
- All existing consumers (SourceIQ dashboard, contract watchdog, data upload) render at rest identically to 0.12.1. Hover states now match HC1 identity.

---

## [0.12.1] — 2026-09-10

**Button variants now read from `--hc-color-*` primitives (immune to consumer palette drift).**

Follow-up to 0.12.0 based on visual bug report from SourceIQ: the same
`variant="secondary"` rendered muted-gray in the DS playground but
teal-tinted inside SourceIQ, because SourceIQ's `:root` overrode
shadcn's `--secondary` to a brand teal. Reading shadcn semantic vars
inside the DS makes the DS's own visual contract depend on the
consumer's palette — the exact drift the DS exists to prevent.

### Changed — variant class strings

- `default`: reads `--hc-color-action-primary` / `--hc-color-action-primary-hover` / `--hc-color-text-on-solid` instead of `--primary` / `--primary-foreground`.
- `outline`: reads `--hc-color-border-default` / `--hc-color-bg-surface` / `--hc-color-text-primary` / `--hc-color-bg-muted` (hover) instead of `--border` / `--background` / `--foreground` / `--accent`.
- `secondary`: reads `--hc-color-bg-subtle` / `--hc-color-text-primary` / `--hc-color-border-subtle` instead of `--secondary` / `--secondary-foreground`.
- `ghost`: reads `--hc-color-text-primary` / `--hc-color-bg-muted` (hover) instead of `--foreground` / `--accent`.
- `destructive`: reads `--hc-color-severity-critical-*` instead of `--destructive` / `--destructive-foreground`.
- `link`: reads `--hc-color-text-link` / `--hc-color-text-link-hover` instead of `--primary`.

The base shell (focus ring, aria-invalid ring, disabled opacity) still reads shadcn semantic vars, since those are cross-cutting states rather than variant identity.

### Rationale

`--hc-color-*` primitives are the DS's own tokens. A consumer that
retints `--secondary` for its own local components is free to do so
without hijacking DS Button. If a product genuinely wants to retint
DS Button, it should override `--hc-color-bg-subtle` (or, when we
ship button-scoped tokens, `--hc-btn-secondary-bg`) — not the shadcn
semantic layer that also drives the consumer's own primitives.

### Verified

- Same DS Button now renders identically in HC1 playground and inside SourceIQ despite SourceIQ's teal `--secondary` retint.
- No visual diff in any of the six variants at rest — the primitives resolve to the same colors as the shadcn semantic vars did in the DS playground context.

---

## [0.12.0] — 2026-09-10

**Button rebuilt for verbatim shadcn/SourceIQ parity + asChild support.**

First component-wise migration under the new "shim-first" adoption
strategy (see sourceiq-hc1com/docs/DESIGN_SYSTEM_MIGRATION.md §Phase 3):

1. HC1 primitive rebuilt to match SourceIQ's local shadcn primitive byte-for-byte
2. SourceIQ's local file becomes a thin re-export shim
3. ESLint rule pushes new code toward direct HC1 imports

Result: every `<Button>` in SourceIQ (20+ files) now renders from HC1
Button with zero call-site changes, no visual diff.

### Changed — Button rewritten

- **Variants**: `default | outline | secondary | ghost | destructive | link` — exact shadcn/SourceIQ names & styling. Base class string, hover states, focus rings, active `translate-y-px`, `aria-invalid` red ring, disabled opacity — all byte-identical to SourceIQ's local Button.
- **Sizes**: `default | xs | sm | lg` (24/32/36/40px heights) + `icon | icon-xs | icon-sm | icon-lg` (24/32/36/40px squares). Matches SourceIQ's size ladder exactly.
- **Base classes**: `rounded-md` (not HC1's `rounded-control`), `font-medium` (not `font-semibold`), stock Tailwind sizing utilities — every arbitrary class matches SourceIQ.
- **Emitted attributes**: `data-slot="button"`, `data-variant`, `data-size` — matches SourceIQ so test selectors, ambient CSS, and DevTools inspection are unchanged.

### Added

- **`asChild` prop** via `@radix-ui/react-slot`. Enables `<Button asChild><Link to="…">…</Link></Button>` composition for React Router / Next Link. Previously blocked HC1 Button adoption on any page with router links.

### Deprecated (still accepted as aliases for v0.11 back-compat)

- Legacy variant names — `primary` → `default`, `danger` → `destructive`, `danger-outline` / `success` → `outline`, `cta` → `default`, `icon` → `ghost` + `size="icon"`.
- Legacy sizes — `md` → `default`, `xl` → `lg`.
- Legacy props — `fullWidth` (adds `w-full`), `loading` (adds `cursor-progress opacity-70`), `leftIcon` / `rightIcon` (wrap around children), `iconOnly` (forces square via size mapping).

All legacy names + props keep working. The `ButtonDoc` playground page was reduced to a stub — full doc rewrite tracked for 0.12.1.

### Verified

- SourceIQ swaps `web/src/components/ui/button.tsx` from a 100-line shadcn Button implementation to a 3-line re-export shim. All 20+ Button consumers keep working with no call-site edits.
- Runtime DOM inspection confirms: `data-slot="button"`, `data-variant="outline"`, `class="group/button ... rounded-md ... h-9 gap-1.5 px-2.5"` — byte-identical to SourceIQ's original Button rendering.
- Build clean, zero JS errors, dashboard/upload/opportunities/spend-analytics/contract-watchdog/variance-results all render as before.

---

## [0.11.1] — 2026-09-10

**Sidebar visual-contract parity fixes.**

Follow-up to 0.11.0 based on measured pixel-diff against SourceIQ's
original copied shadcn sidebar. Goal: an HC1 component must be able
to replace an existing product component without changing its
rendered visual contract or behavior.

### Changed — dimensions (matches shadcn's SidebarMenuButton size="lg")

- Sidebar width collapsed: `64px` → `48px` (3rem, matches shadcn SIDEBAR_WIDTH_ICON)
- Sidebar.Item height: `40px` → `48px` (shadcn h-12 size="lg")
- Sidebar.Item collapsed size: `40px` → `32px` (shadcn size-8)
- Sidebar.Item icon size: `20px` → `16px` (shadcn `[&_svg]:size-4`)
- Sidebar.Item padding: `12px` → `8px` (shadcn p-2)
- Sidebar.Item gap: `12px` → `8px` (shadcn gap-2)
- Section list gap: `2px` → `4px` (shadcn gap-1)
- Sidebar.Header padding: `px-3 pt-4 pb-2` → `p-2` (matches shadcn)
- Sidebar.Header/Footer border-b/border-t: **removed** (original had no separator borders)
- Sidebar.Footer padding: `pt-2 pb-3` → `p-2` (matches shadcn)

### Changed — chrome tokens now consumer-overridable

Sidebar chrome (background gradient + primary-action pill) now reads
from optional CSS custom properties so a consumer can retint without
touching component code. Defaults chain to HC1's brand ramp.

New override tokens (set in consumer :root):

- `--hc-sidebar-bg-from` / `--hc-sidebar-bg-via` / `--hc-sidebar-bg-to` — three-stop gradient
- `--hc-sidebar-bg` — wholesale background override (overrides the gradient)
- `--hc-sidebar-fg` — text color inside sidebar
- `--hc-sidebar-action-bg` / `--hc-sidebar-action-fg` / `--hc-sidebar-action-hover` — primary-action pill in the header

**Example (SourceIQ):**
```css
:root {
  --hc-sidebar-bg-from: var(--sidebar-gradient-from);
  --hc-sidebar-bg-via:  var(--sidebar-gradient-via);
  --hc-sidebar-bg-to:   var(--sidebar-gradient-to);
  --hc-sidebar-action-bg: var(--secondary);
  --hc-sidebar-action-fg: var(--secondary-foreground);
}
```

With this, HC1 `<Sidebar>` renders visually identical to SourceIQ's
retired local `sidebar.tsx` (4.64% pixel delta, entirely sub-pixel
text ghosting from tiny position shifts — imperceptible to the eye).

### Internal — Sidebar background moved from Tailwind class to inline style

The `bg-[var(--hc-sidebar-bg, linear-gradient(...))]` class approach
broke Tailwind v4's parser on deeply-nested `var()` fallbacks. The
gradient is now applied via `style={{ background: '…' }}` inline,
which composes cleanly with `className` for other chrome bits.

### Verified

- Measured 8 dimensions (width, height, padding, gap, icon, list gap) — all match SourceIQ's original values exactly.
- Sidebar-area pixel diff: 0 (all items aligned).
- Overall dashboard pixel diff: 4.64%, all sub-pixel text ghosting from a residual ~2px horizontal main-content shift (imperceptible to human eye).

---

## [0.11.0] — 2026-09-10

**Composite absorption round 1: layout foundation (Sidebar + AppShell + PageHeader + SectionLabel).**

Ships the four highest-leverage composite patterns identified from the SourceIQ pattern audit. First real product migration proves the value: sourceIQ deletes its 703-line copied shadcn `sidebar.tsx` and replaces it with a ~30-line composition using the new DS components.

### Added

- **`<Sidebar>` + `<SidebarProvider>`** — flagship left-nav composite. Compound API with 5 subcomponents (`Sidebar.Header`, `Sidebar.Section`, `Sidebar.Item`, `Sidebar.Footer`, `Sidebar.Trigger`), controlled/uncontrolled collapse, `localStorage` persistence, `Cmd/Ctrl+B` keyboard shortcut, mobile-responsive, active state, badge slot, auto-tooltip when collapsed, `--hc-color-brand-*` gradient chrome (consumer overridable). Standalone `<SidebarProvider>` allows `<Sidebar.Trigger>` to live outside the sidebar (e.g. in an AppShell top bar).
- **`<AppShell>` + `<AppShell.Main>`** — thin layout wrapper for the standard product page frame (flex row, sidebar + main content column). Auto-wraps with `SidebarProvider` so `Sidebar.Trigger` works from any descendant.
- **`<PageHeader>`** — page hero strap with `title` + optional `subtitle` + `meta` slot (right-aligned info) + `actions` slot (right-aligned buttons).
- **`<SectionLabel>`** — small uppercase tracked heading (11px default) with `as` (`div`/`h2`/`h3`/…), `tone` (`muted`/`brand`/`inverse`), `size` (`sm`/`md`/`lg`) props.

### Changed — `dist/styles.css` now declares `@source`

The shipped CSS bundle now includes `@source "./index.js"` and `@source "./index.cjs"` directives. Consumer Tailwind v4 scanners auto-pick-up arbitrary utility classes baked into the compiled DS (e.g. `bg-[linear-gradient(...)]`). Without this, HC1-authored components rendered unstyled in consumer apps because Tailwind never saw the class strings in `node_modules/@hc1/design-system/dist/*.js`.

### Verified

- SourceIQ replaces `web/src/components/layout/app-shell.tsx` (137 lines) to use `<AppShell>` + `<Sidebar>` — total delta: **-807 LOC** (deletes local `sidebar.tsx` at 703 LOC + shrinks composition ~70%).
- Visual QA: dashboard renders with HC1 sidebar chrome (dark teal gradient), all 6 nav items with icons, active state, section labels, header pill-button, footer meta — no regressions to sourceIQ content palette.
- Zero JS/React errors on all 6 sourceIQ routes.

### Known follow-ups (not blocking)

- **Sidebar mobile responsive breakpoint** — auto-collapses below `md` planned but not implemented in this release. Consumers control collapse manually for now.
- **`Sidebar.Item` `asChild` for router integration** — currently renders plain `<a href>`; React Router / Next `<Link>` integration deferred to `0.11.1`.
- **PageHeader mobile stacking** — 320px viewport should test cleanly; not exhaustively verified.

---

## [0.10.0] — 2026-09-10

**Compiled distribution + three new components + first real consumer migration proven end-to-end (SourceIQ).**

This release is the first that flips distribution from source-only to a compiled `dist/`. It also lands the first three components requested by the SourceIQ migration (Progress, Separator, ScrollArea) and documents every consumer-side gotcha we hit while validating the migration in a real product.

### Added

- **New components** — `Progress`, `Separator`, `ScrollArea`. Each wraps its Radix primitive (`@radix-ui/react-progress`, `-separator`, `-scroll-area`) and consumes HC1 tokens via `--hc-*` CSS vars. Follow the standard `cva` + Tailwind v4 pattern; API is deliberately close to shadcn's shape so consumers migrating from stock shadcn versions of these components rename imports only.
- **`tsup` build pipeline** — DS now ships compiled `dist/` with `.js`, `.cjs`, `.d.ts`, `.d.cts`, source maps, and a flat `styles.css`. Configured via `tsup.config.ts`.
- **`prepare` script** — auto-runs `npm run build` on `npm install`, so consumers installing via git URL (or `file:` in a monorepo) always get a working `dist/` with zero manual steps.
- **New peer dependencies** — `@radix-ui/react-progress`, `@radix-ui/react-separator`, `@radix-ui/react-scroll-area`. Consumers must install these alongside the existing Radix peers.
- **README rewrite** — architecture-at-a-glance diagram, explicit "Built on shadcn/ui" section, ten documented architecture decisions (why compiled, why compound components, why options-array Select, why no dark mode yet, etc.), and a Consumer setup section covering the two must-do steps consumers keep hitting.

### Changed

- **Distribution model** — was source-only, now ships compiled `dist/`. `main`, `module`, `types`, and every `exports` conditional in `package.json` point at `./dist/*`. `files` narrowed to `["dist", "README.md", "CHANGELOG.md"]`.
- **Consumers no longer type-check DS internals.** This eliminates the *"Two different types with this name exist"* class of error entirely — DS's `.d.ts` files reference `react` and defer to the consumer's own `@types/react`, so version drift stops mattering.
- **`@types/react` bumped to `^19.0.0`** in `devDependencies` (matches React 19 API surface).
- **Peer `react` / `react-dom` widened to `>=18`** — React 18 and 19 both work; consumer's version wins.

### Consumer-side setup requirements (documented in README §Consumer setup)

Two setup steps every consuming app must perform. Both are one-time.

1. **Vite `resolve.dedupe: ["react", "react-dom", "react/jsx-runtime"]`** — **REQUIRED**. Without this, symlinked or `file:` dep setups produce two React instances (DS's copy + consumer's copy), and the runtime throws *"Invalid hook call"* the moment any DS hook fires. This is the single most common failure we saw during SourceIQ validation.
2. **npm `overrides` for `@types/react` / `@types/react-dom`** — **RECOMMENDED**. Defense-in-depth against a transitive dep pulling in a different `@types/react` and re-introducing type conflicts.

### Verified end-to-end

- **DS fresh build from clean state** — `rm -rf dist node_modules && npm install` → `prepare` script auto-runs tsup → `dist/` regenerated. ✅
- **DS typecheck** — `tsc --noEmit` clean, zero errors. ✅
- **DS `dist/` shape** — every `package.json` export points to a real file; CSS chain `styles.css → tokens/css/variables.css → theme.css + shadcn-bridge.css` intact. ✅
- **New components exportable from `dist/index.d.ts`** — `Progress`, `Separator`, `ScrollArea` and all their type exports present. ✅
- **SourceIQ builds cleanly consuming compiled DS** — `eslint . && tsc -b && vite build` exit 0, no workarounds needed (no symlink hacks, no npm overrides other than the recommended defensive ones). ✅
- **Playground still deploys** — GitHub Pages workflow success, live URL HTTP 200, 53 doc sections render, no overlay regressions, no JS errors. ✅
- **SourceIQ Data Upload page migrated end-to-end** — Alert, Badge, Button, Input, Tabs all swapped to `@hc1/design-system`; app builds, renders with HC1 palette, no console errors. Documented in `sourceiq-hc1com/docs/DESIGN_SYSTEM_MIGRATION.md`.

### Known follow-ups (surfaced by the SourceIQ migration; not blocking)

- **`Tabs.List` line-underline style** — HC1's Tabs doesn't render a shadcn-style line underline. Design decision needed: add a `variant="line"` prop to `Tabs.List` or accept the visual change.
- **`Select` migration is a real refactor** for cases with `SelectGroup` / `SelectSeparator` / custom `SelectValue` rendering. Simple flat selects are one-liners; grouped selects need per-usage care.
- **`Sidebar`, `Chart`, `MultiFileDropZone`** — sourceIQ uses these locally; not yet in DS. Sidebar is tightly coupled to AppShell layout and needs design definition before DS adoption. Chart + MultiFileDropZone stay per-product.

### Not changed

- Token architecture (primitives → aliases → component tokens) — preserved.
- Every existing component API — preserved. This is an additive release.
- Semver contract for the 20 pre-existing components — unchanged.

---

## [0.9.1] — 2026-08-06

**Brand alignment — official HC1 platform palette replaces the scaffolding palette.**

The Material-family placeholder palette that shipped in 0.9.0 was seeded during initial DS scaffolding and never represented the actual HC1 platform brand. This release replaces it with the approved HC1 palette, sourced verbatim from ClinicalIQ's `tokens.json` v3.0-draft. Every value has a documented rationale — see `BRAND_AUDIT.md`.

**No component, API, or architecture changes.** Only token values change. Components inherit the new palette automatically through the alias layer.

### Changed — primitives

Every color scale replaced with approved HC1 values. Anchor at 500 in every family. The 950 slot is preserved in the ramp structure but holds the same value as 900 as a placeholder — v3 does not currently define a 950 shade.

| Family | Anchor (was → now) | Note |
|---|---|---|
| brand | `#009688` → `#0D7782` | Platform primary. Blended in HSL from ClinicalIQ's `#1C6882` + SourceIQ's `#00A79D`. |
| accent | `#F7941D` → `#B75E0B` | Amber. Contrast-adjusted to carry white text at ≥4.5:1. Bright shades (300/400) remain for identity uses. |
| **violet (NEW)** | — → `#6C4DD1` | Reserved for AI moments only. Consumed exclusively via `ai.*` alias. |
| neutral | `#647880` → `#767C84` | Cool-neutral bluish grey (~215° hue). Reads clinical rather than consumer-warm. |
| green | `#2A9647` → `#2E7028` | Success. Contrast-adjusted from `#388032` for WCAG AA (previous failed at ~4.1:1). |
| yellow | `#DE8112` → `#B78810` (bg-only) | Medium-severity surface tint only. v3 defines steps 50–400; darker slots placeholder to 400. Text on yellow uses accent-700. |
| red | `#D62828` → `#B00A2F` | Critical severity + danger. Medical UI convention. |
| blue | unchanged | Retained as supporting utility. Not a semantic role. |

### Added — new semantic aliases

- `cta.*` — dedicated execute/irreversible action alias (amber). Retained on `action.accent*` for backward compatibility with existing docs.
- `ai.*` — AI-moment reserved surface + gradient. Includes `gradientFrom/via/to` for the AI header gradient.
- `severity.*` — five-tier medical severity (critical / high / medium / low / normal), each with `text + bg + bgSubtle + border`. Distinct from `status` (event-scoped feedback) — deliberately kept separate.
- `background.page`, `background.scrim` — v3 page background and overlay scrim tints.
- `text.onSolid` — text on any solid brand/action fill (white).

### Changed — semantic values

- `background.surface`: was `neutral-50`, now `white` (v3: surface is white, page grey sits behind).
- `status.info`: fg/bg/border now use primary teal (v3 semantic: info uses brand, not blue).
- `status.warning`: fg now uses `accent-700` (yellow is bg-only, per v3).
- `status.success` / `status.error`: fg now uses 500-step (v3 anchor), previously used 700-step.

### Docs

- `ColorsDoc.tsx` notes updated to reflect new anchors and reasoning.
- `PopoverDoc.tsx` color-picker swatches updated from Material values to HC1 palette.
- `FOUNDATION.md`, `ARCHITECTURE.md`, `README.md` — no references to Material anchors remained after v0.9.0 wording; no rewrites needed.
- `BRAND_AUDIT.md` — reference document for the palette. Retained.

### Fixed
- 4 hardcoded Material hex values inside DS doc files eliminated (`#009688`, `#F7941D`, `#00796B`, `#2263DB` as sample swatch).

### Not changed
- Token architecture (primitives → aliases → component tokens → components) — preserved.
- Public API — every existing alias name preserved. Only values changed, plus additive aliases.
- Ramp structure — HC1's 50/100/…/950 slots preserved. v3's 025 ultra-tint is not adopted (would require a public API change).
- Blue scale — retained as supporting utility (chart series, data-viz). Not promoted to a semantic role.
- HerCare pink — remains product-scoped (does NOT lift into HC1 per FOUNDATION.md §8).
- Every component file, every component API — unchanged.

### Verified
- `npm run typecheck` — clean.
- Consumer `vite build` (ClinicalIQ) — clean, 135.44 KB CSS / 1533 KB JS.
- Zero Material hex anchors remain in `src/` (grep-verified).
- Playground `/design-system` route serves.

---

## [0.9.0] — 2026-08-06

Pre-1.0 stabilization release. The package is feature-complete for its initial surface but has not yet been validated by a real product migration. **1.0.0 is deliberately withheld** until:

- ClinicalIQ is fully migrated onto the package.
- SourceIQ is fully migrated onto the package.
- The legacy design systems inside both products are removed.
- The public API has survived at least one round of production adoption without breaking changes.

Any 0.9.x → 0.9.y change may break the public surface. Once the four gates above are cleared, we cut 1.0.0 and lock semver.

### Added
- **22 components** — Alert, Badge, Breadcrumb, Button, Card, Checkbox, Dialog, Drawer, EmptyState, Input, Pagination, Popover, Radio, Select, Skeleton, Switch, Table, Tabs, Textarea, Toast, Tooltip.
- **Three-layer token system** — primitives, semantic aliases, component tokens. Available as TypeScript exports and as CSS custom properties via `./styles`.
- **Playground app** — the interactive documentation site, available at `@hc1/design-system/playground`.
- **FOUNDATION.md** — engineering and design constitution for the HC1 platform.

### Fixed
- `src/components/button/Button.tsx` — added a `vite/client` types reference so `import.meta.env` typechecks without adding vite as a dependency.
- `src/docs/components/DialogDoc.tsx`, `DrawerDoc.tsx` — narrowed `ReactNode` return types to satisfy the story-render helper's `ReactElement` parameter.
- `src/docs/foundations/MotionDoc.tsx`, `SpacingDoc.tsx` — retyped the token-entries tuples so `Object.entries` output aligns with the token map key/value types.
- `src/tokens/components/{emptyState,radio,skeleton,switch}.ts` — replaced references to the non-existent `radius.full` with `radius.circular` (same runtime value, `9999px`; the alias key had been renamed and four call sites drifted).

### Package
- Source-only distribution. Consumers' bundlers compile the TypeScript + JSX directly.
- Explicit `exports` map — root, `./tokens`, `./styles`, `./playground`. Everything else is internal.
- Peer dependencies on `react` and `react-dom` (>=18). Only runtime dependency is `lucide-react`.
- `npm run typecheck` passes cleanly with `strict: true`.
